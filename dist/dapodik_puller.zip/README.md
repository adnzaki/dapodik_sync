# dapodik_sync
A simple tool to get Dapodik's data from its local web service.
