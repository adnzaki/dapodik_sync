-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.24-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table db_actudent_sync.tb_agenda
CREATE TABLE IF NOT EXISTS `tb_agenda` (
  `agenda_id` int(11) NOT NULL AUTO_INCREMENT,
  `agenda_name` varchar(250) DEFAULT NULL,
  `agenda_start` datetime DEFAULT NULL,
  `agenda_end` datetime DEFAULT NULL,
  `agenda_description` text DEFAULT NULL,
  `agenda_priority` enum('high','normal','low') DEFAULT NULL,
  `agenda_location` varchar(50) DEFAULT NULL,
  `agenda_attachment` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`agenda_id`),
  KEY `agenda_author` (`user_id`),
  CONSTRAINT `agenda_author` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_agenda: ~42 rows (approximately)
DELETE FROM `tb_agenda`;
INSERT INTO `tb_agenda` (`agenda_id`, `agenda_name`, `agenda_start`, `agenda_end`, `agenda_description`, `agenda_priority`, `agenda_location`, `agenda_attachment`, `user_id`, `created`, `modified`) VALUES
	(6, 'Sosialisasi Ujian Nasional SMKN 999 Kota Bekasi', '2019-06-26 00:00:00', '2019-06-26 23:30:00', 'hahahahaha', 'high', 'sekolah', NULL, 1, '2019-06-26 16:51:51', '2019-06-26 16:51:51'),
	(7, 'Pengumuman Kelulusan SMKN 999 Kota Bekasi', '2019-06-29 08:00:00', '2019-06-29 10:00:00', 'Semangat kalian!!!!', 'high', 'sekolah', '1561543266_4fc5d15c868b378d226a.pdf', 1, '2019-06-26 17:01:06', '2019-06-26 17:01:06'),
	(21, 'Hari pertama PPDB 2019/2020 untuk SD', '2019-07-01 07:00:00', '2019-07-01 14:00:00', 'Semoga berjalan lancar', 'high', 'Sekolah', NULL, 1, '2019-06-30 14:35:51', '2019-06-30 14:35:51'),
	(22, 'HUT RI ke-74', '2019-08-17 00:00:00', '2019-08-17 23:30:00', 'hahaha', 'normal', '', '1566879986_edb42c87f27f38713e42.pdf', 1, '2019-07-01 20:58:14', '2019-08-27 11:26:26'),
	(24, 'Kita adalah siapa', '2019-10-31 10:30:00', '2019-10-31 16:30:00', '', 'low', '', NULL, 1, '2019-07-03 11:22:46', '2019-07-03 11:22:46'),
	(25, 'hhahaha', '2019-11-24 10:00:00', '2019-11-24 11:30:00', 'ssssss', 'normal', '', NULL, 1, '2019-07-03 11:23:12', '2019-07-03 11:23:12'),
	(26, 'Alhamdulillah udah cukup keren..', '2019-07-10 08:30:00', '2019-07-10 10:00:00', 'mantappppss', 'normal', '', NULL, 1, '2019-07-03 17:49:27', '2019-07-03 17:49:27'),
	(27, 'Kegiatan apakah ini?', '2019-07-17 09:00:00', '2019-07-17 16:30:00', '', 'low', '', NULL, 1, '2019-07-15 17:27:51', '2019-07-15 17:27:51'),
	(28, 'Sabtu maiiinnnn', '2019-07-20 20:30:00', '2019-07-20 22:30:00', '', 'high', 'rumah beta', NULL, 1, '2019-07-15 17:28:45', '2019-07-15 17:28:45'),
	(29, 'Coba coba', '2019-07-25 00:00:00', '2019-07-25 23:30:00', '', 'high', 'hehe', NULL, 1, '2019-07-24 23:15:34', '2019-07-24 23:15:34'),
	(30, 'Target selesai halaman edit', '2019-08-24 00:00:00', '2019-08-24 23:30:00', 'Hari ini form edit sudah harus selesai ya bro!!!', 'high', 'Dimana aja yg penting bisa coding', NULL, 1, '2019-08-08 12:07:43', '2019-08-19 14:58:18'),
	(31, 'Alhamdulillah ternyata sudah selesai', '2019-08-19 00:00:00', '2019-08-19 23:30:00', 'mantap dah aing bisa', 'low', 'rumah', '1566546105_be2406fb37814442b20e.pdf', 1, '2019-08-09 02:23:29', '2019-08-23 14:41:45'),
	(32, 'ngasal dulu', '2019-08-22 00:00:00', '2019-08-24 23:30:00', '', 'normal', '', NULL, 1, '2019-08-09 11:32:23', '2019-08-09 11:32:23'),
	(33, 'hari tasyrik', '2019-08-21 00:00:00', '2019-08-21 23:30:00', 'takbir!!', 'high', '', '1566546408_31351a89a7f02372f595.pdf', 1, '2019-08-09 11:34:37', '2019-08-23 14:46:48'),
	(34, 'Sekolah sehat mamen', '2019-08-21 00:00:00', '2019-08-21 23:30:00', 'ayo kita sukseskan kegiatan ini!!!', 'high', 'Sekolah', '1566546147_bcdffbb6acd53dd1371e.pdf', 1, '2019-08-10 12:17:50', '2019-08-23 14:42:26'),
	(35, 'Persiapan PTS Ganjil', '2019-08-29 00:00:00', '2019-08-30 23:30:00', 'Mohon kepada bapak ibu guru partisipasinya.', 'high', 'Sekolah', '1565414411_6b3ca8d7fce3cc1c9fa8.pdf', 1, '2019-08-10 12:20:11', '2019-08-10 12:20:11'),
	(36, 'Ini adalah hari sabtu', '2019-08-31 00:00:00', '2019-08-31 23:30:00', 'okeee', 'high', 'Dimana aja', '1565592050_712411f7ea42f39130d4.pdf', 1, '2019-08-12 13:40:49', '2019-08-12 13:40:49'),
	(37, 'Agenda awal bulan', '2019-09-16 00:00:00', '2019-09-16 23:30:00', '', 'normal', '', NULL, 1, '2019-08-12 13:45:47', '2019-09-12 09:34:19'),
	(40, 'Liburan dulu euy', '2019-08-25 06:00:00', '2019-08-25 23:30:00', '', 'high', '', '1566880075_7c08884baa0e3a13d576.pdf', 1, '2019-08-15 10:58:23', '2019-08-27 11:27:54'),
	(42, 'Maulid Nabi Muhammad', '2019-11-09 07:00:00', '2019-11-09 11:00:00', '', 'high', 'Sekolah', NULL, 1, '2019-11-09 17:42:21', '2019-11-09 17:42:21'),
	(43, 'Mengapa ini terjadi??', '2019-11-13 00:00:00', '2019-11-13 23:30:00', '', 'high', '', NULL, 1, '2019-11-10 10:35:39', '2019-11-10 10:35:39'),
	(44, 'Refreshing dulu masbro', '2020-01-25 08:00:00', '2020-01-25 17:00:00', 'Jalan-jalan sama ndin..', 'high', 'Taman Mini dan Lubang Buaya', NULL, 1, '2020-01-24 13:36:31', '2020-01-24 13:36:31'),
	(45, 'Hari belajar', '2020-03-16 00:00:00', '2020-03-16 23:30:00', '', 'normal', '', '1584002130_6fb36433707371d5b95d.pdf', 1, '2020-03-12 15:35:29', '2020-03-12 15:35:30'),
	(46, 'Akhir April kita ngapain hayo?', '2020-04-30 21:30:00', '2020-05-01 09:00:00', '', 'low', 'dimana aja', '1588495530_86f422d491f4a106337d.pdf', 1, '2020-04-14 12:38:20', '2020-05-03 15:45:30'),
	(47, 'Malem taun baruan', '2020-12-31 00:00:00', '2021-01-01 23:30:00', '', 'normal', 'mana aja udah', NULL, 1, '2020-04-14 13:11:47', '2020-04-14 13:23:07'),
	(48, 'Makan-makan ', '2020-04-16 00:00:00', '2020-04-18 23:30:00', '', 'normal', 'Di rumah masing-masing', NULL, 1, '2020-04-14 19:57:08', '2020-04-14 19:57:08'),
	(49, 'Pra-Pendaftaran Siswa Baru', '2020-06-08 08:00:00', '2020-06-13 13:00:00', 'Persiapan PPDB dimulai dengan upload berkas dan verifikasi dinas.', 'high', 'Sekolah', '1591859791_048da77417873ae22a3b.pdf', 1, '2020-06-04 11:44:50', '2020-06-11 14:18:25'),
	(50, 'RAPAT SEMESTER GANJIL', '2020-06-29 09:00:00', '2020-06-29 12:00:00', '', 'high', 'RPS', NULL, 1, '2020-06-20 10:49:36', '2020-06-20 10:49:36'),
	(51, 'Pendaftaran PPDB SMKN 999 Kota Bekasi', '2020-07-01 09:00:00', '2020-07-04 15:00:00', 'Mulai tanggal 1 hingga 4 Juli SMKN 999 Kota Bekasi menyelenggarakan kegiatan penerimaan peserta didik baru secara online Tahun Ajaran 2019/2020', 'high', 'Sekolah', NULL, 1, '2020-07-02 08:57:40', '2020-07-02 08:57:40'),
	(52, 'Sosialisasi aplikasi Actudent', '2020-07-06 08:00:00', '2020-07-06 11:00:00', 'SMKN 999 Kota Bekasi akan mengadakan sosialisasi Actudent kepada orang tua dan guru', 'high', 'Ruang Aula', NULL, 1, '2020-07-02 09:06:09', '2020-07-02 09:06:09'),
	(53, 'Menyusun laporan keuangan akhir tahun', '2020-12-29 08:00:00', '2020-12-30 16:00:00', 'ayo selesaikan', 'high', '', NULL, 1, '2020-12-29 16:31:48', '2020-12-29 16:31:48'),
	(54, 'Hari pertama masuk sekolah tatap muka', '2021-01-04 07:00:00', '2021-01-04 12:00:00', '', 'normal', 'di sekolah', NULL, 1, '2021-01-01 13:47:13', '2021-01-01 13:47:13'),
	(55, 'Percobaan 1', '2022-05-24 23:03:00', '2022-05-25 00:03:00', '', 'normal', '', '1653408198_4cedd6b718955067f86f.pdf', 1, '2022-05-24 23:03:20', '2022-05-24 23:03:20'),
	(56, 'Percobaan 2', '2022-05-24 08:00:00', '2022-05-25 07:45:00', '', 'normal', '', '', 1, '2022-05-24 23:04:03', '2022-05-24 23:04:03'),
	(57, 'rencana kita esok hari', '2022-06-17 07:00:00', '2022-06-17 09:45:00', '', 'normal', '', '', 1, '2022-06-16 23:38:48', '2022-06-16 23:38:48'),
	(58, 'Persiapan HUT RI ke-77', '2022-08-10 10:00:00', '2022-08-10 12:00:00', 'Penyusunan rencana kegiatan pelaksanaan HUT RI ke-77', 'high', 'Ruang Aula', '1659585275_53fcb0e84438d874a889.pdf', 1, '2022-08-04 10:55:05', '2022-08-04 10:55:05'),
	(61, 'testtttt', '2022-08-04 22:20:00', '2022-08-04 23:20:00', '', 'normal', '', '', 1, '2022-08-04 22:20:41', '2022-08-04 22:20:41'),
	(64, 'testtttt', '2022-09-13 10:35:00', '2022-09-13 11:35:00', '', 'normal', '', '', 1, '2022-09-13 10:35:18', '2022-09-13 10:35:18'),
	(65, 'auuuuu', '2022-09-13 10:36:00', '2022-09-13 11:36:00', '', 'normal', '', '', 1, '2022-09-13 10:36:17', '2022-09-13 10:36:17'),
	(66, 'hebuuuu', '2022-09-13 10:36:00', '2022-09-13 11:36:00', '', 'normal', '', '', 1, '2022-09-13 10:36:39', '2022-09-13 10:36:39'),
	(67, 'Kemaaaah coy', '2022-11-28 07:00:00', '2022-11-30 08:30:00', 'main kemah-kemahan', 'high', 'sekolah', '', 1, '2022-11-27 20:50:52', '2022-11-27 21:43:26'),
	(68, 'Halal bi Halal', '2023-04-26 07:30:00', '2023-04-26 08:30:00', 'Halal bi Halal Idul Fitri di sekolah', 'high', 'Halaman Sekolah', '', 1, '2023-04-20 10:06:40', '2023-04-20 10:06:40');

-- Dumping structure for table db_actudent_sync.tb_agenda_user
CREATE TABLE IF NOT EXISTS `tb_agenda_user` (
  `agenda_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `present` int(11) NOT NULL DEFAULT 0,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_agenda_user: ~18 rows (approximately)
DELETE FROM `tb_agenda_user`;
INSERT INTO `tb_agenda_user` (`agenda_id`, `user_id`, `present`, `created`, `modified`) VALUES
	(61, 72, 0, '2022-08-04 22:53:14', '2022-08-04 22:53:14'),
	(61, 73, 0, '2022-08-04 22:53:14', '2022-08-04 22:53:14'),
	(61, 4, 0, '2022-08-04 22:53:14', '2022-08-04 22:53:14'),
	(68, 49, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 72, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 73, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 4, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 78, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 71, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 53, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 69, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 13, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 12, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 79, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 80, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 48, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 34, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05'),
	(68, 26, 0, '2023-04-20 10:08:05', '2023-04-20 10:08:05');

-- Dumping structure for table db_actudent_sync.tb_chat
CREATE TABLE IF NOT EXISTS `tb_chat` (
  `chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_user_id` int(11) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `read_status` int(11) DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`chat_id`),
  KEY `chat_user` (`chat_user_id`),
  CONSTRAINT `chat_user` FOREIGN KEY (`chat_user_id`) REFERENCES `tb_chat_users` (`chat_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_chat: ~8 rows (approximately)
DELETE FROM `tb_chat`;
INSERT INTO `tb_chat` (`chat_id`, `chat_user_id`, `sender`, `content`, `read_status`, `created`) VALUES
	(1, 1, 1, 'selamat siang pak rizal', 1, '2020-12-23 04:48:29'),
	(2, 1, 53, 'siang pak zaki', 1, '2020-12-23 04:49:02'),
	(3, 1, 1, 'halo halo', 1, '2021-01-07 07:27:31'),
	(4, 1, 1, 'hai hai', 1, '2021-01-07 07:29:41'),
	(5, 1, 1, 'hai juga..', 1, '2021-01-13 05:07:57'),
	(6, 1, 1, 'eh itu kan saya sendiri', 1, '2021-01-13 05:08:03'),
	(7, 1, 53, 'apasih astaghfirullah..', 1, '2021-01-19 03:21:07'),
	(8, 1, 1, 'ngga', 0, '2021-02-07 10:10:59');

-- Dumping structure for table db_actudent_sync.tb_chat_users
CREATE TABLE IF NOT EXISTS `tb_chat_users` (
  `chat_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `participant_1` varchar(5) DEFAULT NULL,
  `participant_2` varchar(5) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`chat_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_chat_users: ~1 rows (approximately)
DELETE FROM `tb_chat_users`;
INSERT INTO `tb_chat_users` (`chat_user_id`, `participant_1`, `participant_2`, `created`) VALUES
	(1, '1', '53', '2020-12-23 04:48:29');

-- Dumping structure for table db_actudent_sync.tb_grade
CREATE TABLE IF NOT EXISTS `tb_grade` (
  `grade_id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_name` varchar(50) DEFAULT NULL,
  `period_start` varchar(4) DEFAULT NULL,
  `period_end` varchar(4) DEFAULT NULL,
  `teacher_id` int(11) NOT NULL,
  `grade_status` tinyint(1) DEFAULT NULL,
  `rombel_dapodik_id` varchar(50) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`grade_id`),
  KEY `wali_kelas` (`teacher_id`),
  CONSTRAINT `wali_kelas` FOREIGN KEY (`teacher_id`) REFERENCES `tb_staff` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_grade: ~0 rows (approximately)
DELETE FROM `tb_grade`;

-- Dumping structure for table db_actudent_sync.tb_homework
CREATE TABLE IF NOT EXISTS `tb_homework` (
  `journal_id` int(11) NOT NULL,
  `homework_title` varchar(300) DEFAULT NULL,
  `homework_description` varchar(500) DEFAULT NULL,
  `due_date` timestamp NULL DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `journal_homework` (`journal_id`),
  CONSTRAINT `journal_homework` FOREIGN KEY (`journal_id`) REFERENCES `tb_journal` (`journal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_homework: ~0 rows (approximately)
DELETE FROM `tb_homework`;

-- Dumping structure for table db_actudent_sync.tb_journal
CREATE TABLE IF NOT EXISTS `tb_journal` (
  `journal_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_archive` int(11) NOT NULL DEFAULT 0,
  `journal_date` date DEFAULT current_timestamp(),
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`journal_id`),
  KEY `schedule_journal` (`schedule_id`),
  CONSTRAINT `schedule_journal` FOREIGN KEY (`schedule_id`) REFERENCES `tb_schedule` (`schedule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_journal: ~0 rows (approximately)
DELETE FROM `tb_journal`;

-- Dumping structure for table db_actudent_sync.tb_lessons
CREATE TABLE IF NOT EXISTS `tb_lessons` (
  `lesson_id` int(11) NOT NULL AUTO_INCREMENT,
  `lesson_code` varchar(50) NOT NULL,
  `lesson_name` varchar(100) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`lesson_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_lessons: ~17 rows (approximately)
DELETE FROM `tb_lessons`;
INSERT INTO `tb_lessons` (`lesson_id`, `lesson_code`, `lesson_name`, `deleted`, `created`, `modified`) VALUES
	(1, 'MTK', 'Matematika', 0, '2020-03-21 12:44:18', '2020-03-21 12:44:18'),
	(2, 'BIND', 'Bahasa Indonesia', 0, '2020-03-21 12:44:18', '2020-03-21 12:44:18'),
	(3, 'BING', 'Bahasa Inggris', 0, '2020-03-21 12:44:18', '2020-03-21 12:44:18'),
	(4, 'PAI', 'Pendidikan Agama Islam', 0, '2020-03-21 12:44:18', '2020-03-21 12:44:18'),
	(5, 'PKN', 'Pendidikan Kewarganegaraan', 0, '2020-03-21 12:44:18', '2020-03-21 12:44:18'),
	(6, 'PJOK', 'Pendidikan Jasmani, Olahraga dan Kesehatan', 0, '2020-03-21 12:44:18', '2020-03-21 12:44:18'),
	(7, 'IPS', 'Ilmu Pengetahuan Sosial', 0, '2020-04-05 12:11:11', '2020-04-05 12:11:11'),
	(8, 'PLH', 'Pendidikan Lingkungan Hidup', 0, '2020-04-05 12:11:55', '2020-04-05 12:11:55'),
	(9, 'FSK', 'Fisika', 0, '2020-04-17 10:10:07', '2020-04-17 10:10:07'),
	(10, 'KMA', 'Kimia', 0, '2020-04-17 10:10:16', '2020-04-17 10:10:16'),
	(11, 'BIO', 'Biologi', 0, '2020-04-17 10:10:24', '2020-04-17 10:10:24'),
	(12, 'PRD', 'Pemrograman Dasar', 0, '2020-04-17 10:10:58', '2020-04-17 10:10:58'),
	(13, 'KGRF', 'Kalkulasi Grafika', 0, '2020-05-28 22:51:38', '2020-05-28 22:51:38'),
	(14, 'DGR', 'Desain Grafis', 0, '2020-05-28 22:51:50', '2020-05-28 22:51:50'),
	(15, 'IKOM', 'Instalasi Komputer', 0, '2020-07-09 05:42:05', '2020-07-09 05:42:05'),
	(16, 'PRG', 'Pemrograman Dasar', 1, '2020-07-09 05:43:19', '2021-01-13 05:09:24'),
	(17, 'KLK', 'Kalkulussss', 1, '2023-04-17 07:29:05', '2023-04-17 07:29:32');

-- Dumping structure for table db_actudent_sync.tb_lessons_grade
CREATE TABLE IF NOT EXISTS `tb_lessons_grade` (
  `lessons_grade_id` int(11) NOT NULL AUTO_INCREMENT,
  `lesson_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`lessons_grade_id`),
  KEY `fk_teacher_lesson` (`teacher_id`),
  KEY `fk_grade_lesson` (`grade_id`),
  KEY `fk_lesson` (`lesson_id`),
  CONSTRAINT `fk_grade_lesson` FOREIGN KEY (`grade_id`) REFERENCES `tb_grade` (`grade_id`),
  CONSTRAINT `fk_lesson` FOREIGN KEY (`lesson_id`) REFERENCES `tb_lessons` (`lesson_id`),
  CONSTRAINT `fk_teacher_lesson` FOREIGN KEY (`teacher_id`) REFERENCES `tb_staff` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_lessons_grade: ~0 rows (approximately)
DELETE FROM `tb_lessons_grade`;

-- Dumping structure for table db_actudent_sync.tb_parent
CREATE TABLE IF NOT EXISTS `tb_parent` (
  `parent_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `parent_family_card` varchar(18) DEFAULT NULL,
  `parent_father_name` varchar(100) DEFAULT NULL,
  `parent_mother_name` varchar(100) DEFAULT NULL,
  `parent_phone_number` varchar(15) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` timestamp NULL DEFAULT current_timestamp(),
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`parent_id`,`user_id`) USING BTREE,
  KEY `fk_parent` (`user_id`),
  CONSTRAINT `fk_parent` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_parent: ~0 rows (approximately)
DELETE FROM `tb_parent`;

-- Dumping structure for table db_actudent_sync.tb_presence
CREATE TABLE IF NOT EXISTS `tb_presence` (
  `journal_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `presence_status` int(11) DEFAULT NULL,
  `presence_mark` varchar(300) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`journal_id`,`student_id`),
  KEY `student_presence` (`student_id`),
  CONSTRAINT `presence_journal` FOREIGN KEY (`journal_id`) REFERENCES `tb_journal` (`journal_id`),
  CONSTRAINT `student_presence` FOREIGN KEY (`student_id`) REFERENCES `tb_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_presence: ~0 rows (approximately)
DELETE FROM `tb_presence`;

-- Dumping structure for table db_actudent_sync.tb_room
CREATE TABLE IF NOT EXISTS `tb_room` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_name` varchar(300) DEFAULT NULL,
  `room_code` varchar(50) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `created` timestamp NULL DEFAULT current_timestamp(),
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_room: ~10 rows (approximately)
DELETE FROM `tb_room`;
INSERT INTO `tb_room` (`room_id`, `room_name`, `room_code`, `deleted`, `created`, `modified`) VALUES
	(1, 'Ruang 113', 'R113', 0, '2020-04-23 15:11:56', '2020-04-23 15:11:56'),
	(2, 'Ruang 114', 'R114', 0, '2020-04-23 15:11:56', '2020-04-23 15:11:56'),
	(3, 'Ruang 098', 'R098', 0, '2020-05-28 22:41:27', '2020-05-28 22:43:49'),
	(4, 'Laboratorium Komputer 1', 'LAB01', 0, '2020-05-28 22:42:00', '2020-05-28 22:43:51'),
	(5, 'Ruang 100', 'R100', 0, '2020-05-28 22:45:14', '2020-05-28 22:45:14'),
	(6, 'Ruang 120', 'R120', 0, '2020-06-20 03:40:44', '2020-06-20 03:40:44'),
	(7, 'KELAS 10', 'R01', 0, '2020-06-20 03:41:50', '2020-06-20 03:41:50'),
	(8, 'Ruang 101', 'R101_deleted_1495992912', 1, '2023-04-17 07:23:30', '2023-04-17 07:23:52'),
	(9, 'Ruang 101', 'R101', 0, '2023-04-17 07:23:59', '2023-04-17 07:23:59'),
	(10, 'Ruang 102', 'R102', 0, '2023-04-17 07:24:05', '2023-04-17 07:24:05');

-- Dumping structure for table db_actudent_sync.tb_schedule
CREATE TABLE IF NOT EXISTS `tb_schedule` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `lessons_grade_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `schedule_semester` int(11) DEFAULT NULL,
  `schedule_day` varchar(20) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `schedule_start` varchar(10) DEFAULT NULL,
  `schedule_end` varchar(10) DEFAULT NULL,
  `schedule_order` int(11) DEFAULT NULL,
  `schedule_status` enum('active','inactive','','') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`schedule_id`),
  KEY `lessons_grade` (`lessons_grade_id`),
  KEY `room` (`room_id`),
  CONSTRAINT `lessons_grade` FOREIGN KEY (`lessons_grade_id`) REFERENCES `tb_lessons_grade` (`lessons_grade_id`),
  CONSTRAINT `room` FOREIGN KEY (`room_id`) REFERENCES `tb_room` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_schedule: ~0 rows (approximately)
DELETE FROM `tb_schedule`;

-- Dumping structure for table db_actudent_sync.tb_schedule_settings
CREATE TABLE IF NOT EXISTS `tb_schedule_settings` (
  `schedule_setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(100) DEFAULT NULL,
  `setting_value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`schedule_setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_schedule_settings: ~2 rows (approximately)
DELETE FROM `tb_schedule_settings`;
INSERT INTO `tb_schedule_settings` (`schedule_setting_id`, `setting_name`, `setting_value`) VALUES
	(1, 'lesson_hour', '45'),
	(2, 'start_time', '7');

-- Dumping structure for table db_actudent_sync.tb_school
CREATE TABLE IF NOT EXISTS `tb_school` (
  `school_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(300) NOT NULL,
  `school_type` enum('Sekolah Dasar','Sekolah Menengah Pertama','Sekolah Manengah Atas') NOT NULL,
  `school_address` varchar(500) DEFAULT NULL,
  `school_telephone` varchar(30) DEFAULT NULL,
  `school_status` tinyint(1) NOT NULL,
  `school_domain` varchar(255) NOT NULL,
  `school_letterhead` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT current_timestamp(),
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_school: ~1 rows (approximately)
DELETE FROM `tb_school`;
INSERT INTO `tb_school` (`school_id`, `school_name`, `school_type`, `school_address`, `school_telephone`, `school_status`, `school_domain`, `school_letterhead`, `created`, `modified`) VALUES
	(1, 'SMK Negeri 999 Kota Bekasi', 'Sekolah Manengah Atas', 'Jl. Raya Pekayon No. 30', '(021) 800398493', 1, 'demo.actudent.com', '{\r\n    "city": "Bekasi",\r\n    "website": "smkn999kotabekasi.sch.id",\r\n    "email": "smkn999kotabekasi@yahoo.com",\r\n    "opd_logo": "logo-opd.png",\r\n    "school_logo": "logo-sekolah.png",\r\n    "opd_name": "Pemerintah Provinsi Jawa Barat",\r\n    "sub_opd_name": "Kantor Cabang Dinas Wilayah IV",\r\n    "headmaster": "Dr. Raihan, M.Pd.",\r\n    "headmaster_nip": "19631212 198410 1 012",\r\n    "co_headmaster": "Rino Swastika, S.Pd",\r\n    "co_headmaster_nip": "19631212 198410 1 012"\r\n}', '2018-10-09 17:00:00', '2020-07-11 01:32:19');

-- Dumping structure for table db_actudent_sync.tb_score
CREATE TABLE IF NOT EXISTS `tb_score` (
  `score_id` int(11) NOT NULL AUTO_INCREMENT,
  `lessons_grade_id` int(11) NOT NULL,
  `score_type` enum('Teori','Praktik') NOT NULL,
  `score_category` enum('Tugas','UH','PTS','PAS','Kinerja','Proyek') NOT NULL,
  `score_description` varchar(250) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`score_id`),
  KEY `score_lessons_grade` (`lessons_grade_id`),
  CONSTRAINT `score_lessons_grade` FOREIGN KEY (`lessons_grade_id`) REFERENCES `tb_lessons_grade` (`lessons_grade_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_score: ~0 rows (approximately)
DELETE FROM `tb_score`;

-- Dumping structure for table db_actudent_sync.tb_score_student
CREATE TABLE IF NOT EXISTS `tb_score_student` (
  `score_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `score` decimal(10,2) NOT NULL,
  `score_note` text DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`score_id`,`student_id`),
  KEY `score_student` (`student_id`),
  CONSTRAINT `score_id` FOREIGN KEY (`score_id`) REFERENCES `tb_score` (`score_id`),
  CONSTRAINT `score_student` FOREIGN KEY (`student_id`) REFERENCES `tb_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_score_student: ~0 rows (approximately)
DELETE FROM `tb_score_student`;

-- Dumping structure for table db_actudent_sync.tb_staff
CREATE TABLE IF NOT EXISTS `tb_staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `staff_nik` varchar(20) DEFAULT NULL,
  `staff_name` varchar(50) DEFAULT NULL,
  `staff_phone` varchar(20) DEFAULT NULL,
  `staff_type` enum('teacher','staff') DEFAULT NULL,
  `staff_title` varchar(100) DEFAULT NULL,
  `staff_photo` text DEFAULT NULL,
  `staff_tag` tinyint(1) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` timestamp NULL DEFAULT current_timestamp(),
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`staff_id`),
  KEY `fk_staff_user` (`user_id`),
  CONSTRAINT `fk_staff_user` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_staff: ~0 rows (approximately)
DELETE FROM `tb_staff`;

-- Dumping structure for table db_actudent_sync.tb_student
CREATE TABLE IF NOT EXISTS `tb_student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_nis` varchar(20) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_tag` tinyint(1) DEFAULT 1,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_student: ~0 rows (approximately)
DELETE FROM `tb_student`;

-- Dumping structure for table db_actudent_sync.tb_student_grade
CREATE TABLE IF NOT EXISTS `tb_student_grade` (
  `student_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `student_tag` tinyint(1) DEFAULT 1,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`student_id`,`grade_id`),
  KEY `fk_grade` (`grade_id`),
  CONSTRAINT `fk_grade` FOREIGN KEY (`grade_id`) REFERENCES `tb_grade` (`grade_id`),
  CONSTRAINT `fk_student` FOREIGN KEY (`student_id`) REFERENCES `tb_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_student_grade: ~0 rows (approximately)
DELETE FROM `tb_student_grade`;

-- Dumping structure for table db_actudent_sync.tb_student_parent
CREATE TABLE IF NOT EXISTS `tb_student_parent` (
  `parent_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `fk_student_parent` (`student_id`),
  KEY `parent` (`parent_id`) USING BTREE,
  CONSTRAINT `fk_ortu` FOREIGN KEY (`parent_id`) REFERENCES `tb_parent` (`parent_id`),
  CONSTRAINT `fk_student_parent` FOREIGN KEY (`student_id`) REFERENCES `tb_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_student_parent: ~0 rows (approximately)
DELETE FROM `tb_student_parent`;

-- Dumping structure for table db_actudent_sync.tb_timeline
CREATE TABLE IF NOT EXISTS `tb_timeline` (
  `timeline_id` int(11) NOT NULL AUTO_INCREMENT,
  `timeline_title` varchar(100) DEFAULT NULL,
  `timeline_content` text DEFAULT NULL,
  `timeline_date` datetime DEFAULT NULL,
  `timeline_status` enum('public','draft') DEFAULT NULL,
  `timeline_image` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`timeline_id`),
  KEY `timeline_author` (`user_id`),
  CONSTRAINT `timeline_author` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_timeline: ~4 rows (approximately)
DELETE FROM `tb_timeline`;
INSERT INTO `tb_timeline` (`timeline_id`, `timeline_title`, `timeline_content`, `timeline_date`, `timeline_status`, `timeline_image`, `user_id`, `created`, `modified`) VALUES
	(1, 'Selamat datang di Actudent!', 'Kami warga sekolah sangat bahagia dengan adanya aplikasi ini', '2020-06-30 21:40:29', 'public', 'img_1593528032_857e09b06a5a9d189b74.jpg', 1, '2020-06-25 00:28:57', '2020-06-30 21:40:32'),
	(2, 'Ceritakan banyak hal tentang sekolah anda', 'Di dalam fitur timeline ini anda bisa dengan bebas membagikan banyak cerita tentang sekolah anda kepada guru dan orang tua murid yang menggunakan aplikasi Actudent. Jadikan semua informasi up-to date!', '2020-06-30 21:39:29', 'public', 'img_1593527976_53f1c747b348f72f7539.jpg', 1, '2020-06-25 00:30:29', '2020-06-30 21:39:37'),
	(3, 'Buat kabar terbaru di mana saja! ', 'Tahukah kamu, postingan ini dibuat hanya dengan menggunakan sebuah ponsel!', '2020-06-30 21:43:08', 'public', 'img_1593528157_93bbdc6e76b3c7cdf617.jpg', 1, '2020-06-30 21:42:33', '2020-06-30 21:43:08'),
	(4, 'Istirahat sejenak, mulailah bercerita', 'Luangkan waktu anda dan cobalah untuk lebih banyak berbagi dengan orang di sekitar anda, termasuk para orang tua siswa.', '2020-07-02 00:56:27', 'public', 'img_1593557529_b8eadabe1142c315a8b0.jpg', 1, '2020-06-30 21:45:01', '2020-07-02 00:56:27');

-- Dumping structure for table db_actudent_sync.tb_timeline_comments
CREATE TABLE IF NOT EXISTS `tb_timeline_comments` (
  `timeline_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `timeline_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment_parent` int(11) DEFAULT NULL,
  `comment_content` text DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`timeline_comment_id`),
  KEY `fk_timeline` (`timeline_id`),
  KEY `comment_author` (`user_id`),
  CONSTRAINT `comment_author` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`),
  CONSTRAINT `fk_timeline` FOREIGN KEY (`timeline_id`) REFERENCES `tb_timeline` (`timeline_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_timeline_comments: ~0 rows (approximately)
DELETE FROM `tb_timeline_comments`;

-- Dumping structure for table db_actudent_sync.tb_timeline_likes
CREATE TABLE IF NOT EXISTS `tb_timeline_likes` (
  `timeline_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`timeline_id`,`user_id`),
  KEY `like_author` (`user_id`),
  CONSTRAINT `fk_timeline_like` FOREIGN KEY (`timeline_id`) REFERENCES `tb_timeline` (`timeline_id`),
  CONSTRAINT `like_author` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_timeline_likes: ~0 rows (approximately)
DELETE FROM `tb_timeline_likes`;

-- Dumping structure for table db_actudent_sync.tb_timelog
CREATE TABLE IF NOT EXISTS `tb_timelog` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_nis` varchar(20) DEFAULT NULL,
  `verifymode` tinyint(4) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  `iomode` tinyint(4) DEFAULT NULL,
  `created` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_timelog: ~2 rows (approximately)
DELETE FROM `tb_timelog`;
INSERT INTO `tb_timelog` (`log_id`, `student_nis`, `verifymode`, `timestamp`, `iomode`, `created`) VALUES
	(1, '2015420022', 1, '2020-04-23 14:34:06', 1, '2020-04-23 16:42:09'),
	(2, '1920209189', 1, '2020-04-20 14:34:06', 1, '2020-04-23 16:42:09');

-- Dumping structure for table db_actudent_sync.tb_user
CREATE TABLE IF NOT EXISTS `tb_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_level` tinyint(4) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `network` varchar(10) NOT NULL DEFAULT 'offline',
  `created` timestamp NULL DEFAULT current_timestamp(),
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_user: ~72 rows (approximately)
DELETE FROM `tb_user`;
INSERT INTO `tb_user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_level`, `deleted`, `network`, `created`, `modified`) VALUES
	(1, 'Adnan Zaki', 'admin@localhost', '$2y$10$gKk1sx1Jx/cXx2L8BolU4emqDn2Kg/zSr9hqOb7Syo5NpisY.QnwC', 1, 0, 'online', '2018-10-10 17:00:00', '2021-04-04 16:39:11'),
	(2, 'Mukhlisin', 'mukliz@wolestech.com', '$2y$10$8n/ojdr/Cb6DjfBIjVKkvekVHXfjXAATlWlnsMZAvV9ioz7Zv/La2', 0, 1, 'offline', '2018-10-30 17:00:00', '2022-11-29 02:32:17'),
	(3, 'Dany Prastio', 'danyprastio@wolestech.com', '$2y$10$UpUUj08e6BuSfzOWqUJvQ.Y6ue8CCO/98RKshSx3hJL7OF5tkrpUe', 0, 1, 'offline', '2018-10-30 17:00:00', '2022-11-29 02:31:19'),
	(4, 'Firhan Yudha Prakoso', 'firhanyp@localhost', '$2y$10$UpwiDBoQlI5CRUi1DDDNH.di.FSAtnmKXqRAG6HXVwNqQf1R13vWq', 2, 0, 'online', '2019-03-17 17:00:00', '2023-07-06 04:02:16'),
	(12, 'Uus Rusmawan Prasetyo', 'uusrusmawan@smkn11kotabekasi.actudent.com', '$2y$10$sHHFUTN8js.27Nz3exYru..1Sq6kyNOcGGy/1AGR5SYECvBiAc0Aq', 2, 0, 'online', '2019-03-27 17:00:00', '2022-06-20 16:32:03'),
	(13, 'Sudrajat', 'sudrajat@demo.actudent.com', '$2y$10$uRTcEtv.NxzipbhTI5mXPOrC7mWw4j7MSOJ5up8gztVR/YqZ.cg5a', 2, 0, 'online', '2019-03-28 17:00:00', '2020-07-10 06:17:32'),
	(14, 'Bambang Tri', 'bambang@smkn11kotabekasi.actudent.com', '$2y$10$3qsfIV6tYUkZvCgs6uTu6.X4lnZnLP2.ZVDixeL/Obk0cuRlt0o1S', 0, 1, 'offline', '2020-02-08 05:04:31', '2020-06-17 07:20:50'),
	(15, 'Sinto', 'sinto@smkn11kotabekasi.actudent.com', '$2y$10$ZUfIX77V.H8HZYsENgFoH.QhdH8jBpDrzKb3UXCb/yQISzuxTfnvy', 0, 1, 'offline', '2020-02-08 05:06:12', '2020-06-17 07:20:50'),
	(16, 'Rizky Nur Hidayat', 'rizkynur@smkn11kotabekasi.actudent.com', '$2y$10$FQnHnmSSTgW6mUYb8B/Lxer3ltbmcBuijIrY4qQr4szfM063heMyC', 0, 1, 'offline', '2020-02-10 02:54:50', '2020-06-17 07:20:50'),
	(17, 'Bernard Siahaan', 'bernard@smkn11kotabekasi.actudent.com', '$2y$10$4aBQchBOsJmjj5FSi4q3vOtp1oC4gaoz9FrobyyjgeIagp3SKY9Hy', 0, 1, 'offline', '2020-02-10 03:01:31', '2020-06-17 07:20:50'),
	(23, 'Susanto Nurjaman', 'susantonur@smkn11kotabekasi.actudent.com', '$2y$10$OPDJcB9JSaS8m9KnqJbFHOMkC//xz6o69WOTzAIHqyOtZ63/6KE1u', 0, 1, 'offline', '2020-02-10 07:33:09', '2022-11-29 02:32:31'),
	(24, 'Ahmad Ridho', 'ahmad.ridho@smkn11kotabekasi.actudent.com', '$2y$10$tiSdWeWFn9.l6KR.JQzkw.G6AEXJtQjwMz7otMwc8zUFwQt49EK/e', 0, 1, 'offline', '2020-02-10 07:34:15', '2022-11-28 15:30:40'),
	(25, 'Fahruliansyah', 'fahruliansyah@smkn11kotabekasi.actudent.com', '$2y$10$sHnfCCQmtA1CCsGH5V/v7u5bjbDMhYJcGQ2rhGKeL2Y0mX8YmkkHO', 0, 1, 'offline', '2020-02-10 07:35:17', '2022-11-29 02:31:32'),
	(26, 'Andreas Prasetyo', 'andreas.prasetya@smkn11kotabekasi.actudent.com', '$2y$10$f2Vf06NLCbTYGLO2opRWlOcxTsnlRPVpY0dQxeMUwmfYv1ooiiNk2', 0, 1, 'offline', '2020-02-10 07:35:53', '2022-11-29 02:30:46'),
	(27, 'Emet Nur Cholis', 'emet.cholis@smkn11kotabekasi.actudent.com', '$2y$10$xeeenDsJ1.U3UaGAXarBWOf2GhtbdXnApe9G9aPfqvfHUlYW1p4Me', 0, 1, 'offline', '2020-02-10 07:38:11', '2022-11-29 02:31:29'),
	(28, 'Gledek Nurmantyo', 'gledek.nur@smkn11kotabekasi.actudent.com', '$2y$10$VuBTeKY26z1.ZD7bigwanuBwZawaabZ4nO3/MiOPpWoEQTvbLC0Gi', 0, 1, 'offline', '2020-02-10 08:10:10', '2022-11-29 02:31:35'),
	(29, 'asdgvfevbds', 'asdgvfevbds@smkn11kotabekasi.actudent.com', '$2y$10$m6dhzqnTeTeHSapp7ncDweLxGsmCk4cpCVjtMS22XGJx72KMXpG9W', 0, 1, 'offline', '2020-02-10 08:15:03', '2022-11-29 02:30:59'),
	(30, 'Badut Siahaan', 'badut.siahaan@demo.actudent.com', '$2y$10$uRTcEtv.NxzipbhTI5mXPOrC7mWw4j7MSOJ5up8gztVR/YqZ.cg5a', 3, 0, 'offline', '2020-02-10 08:16:45', '2020-06-30 08:58:58'),
	(31, 'Katmo', 'yuhu@smkn11kotabekasi.actudent.com', '$2y$10$QCZkcT17AjFTDqsMEk5B.OyPaplWSv5JmiN/LfOvH7Doi9hFBjdyu', 0, 1, 'offline', '2020-02-10 08:16:56', '2022-11-29 02:32:05'),
	(32, 'Abdi Negara', 'abdinegara@smkn11kotabekasi.actudent.com', '$2y$10$ep.TCSdv6GKxg1gcTVoecuHpY4/mKRRhiKgKUm.XllM/SAhoerY9i', 0, 1, 'online', '2020-02-10 08:17:14', '2022-11-28 08:42:06'),
	(33, 'Yono', 'ahay@smkn11kotabekasi.actudent.com', '$2y$10$fiKYu1o07/j5vAGRdjsbWugXl5msV3KBmh2.3YjP8xGxeDQmsgR4u', 0, 1, 'offline', '2020-02-10 08:17:33', '2022-11-29 02:32:35'),
	(34, 'Amran Kartakarun', 'lelejepang@smkn11kotabekasi.actudent.com', '$2y$10$519EUkbcNvfhUDCnMWmU0.gGVBIxTlpvABpYfAbyVjsoaxLUq21GC', 0, 1, 'offline', '2020-02-10 08:17:53', '2022-11-28 14:58:23'),
	(35, 'Jajang', 'bedul@smkn11kotabekasi.actudent.com', '$2y$10$VgvRgehTFqw.zT18.WhFneNCRTH6UAh8qosqAMqQQC9qEGBOZUmne', 0, 1, 'offline', '2020-02-10 08:18:10', '2022-11-29 02:32:03'),
	(36, 'Sandrayono', 'didikempot@smkn11kotabekasi.actudent.com', '$2y$10$aJ2zsiCmT9vEkp2XeyK1WuVVG4ielaNRMK2C9BTCB/m3UMjl/zxSe', 0, 1, 'offline', '2020-02-10 08:19:23', '2022-11-29 02:32:28'),
	(37, 'Anto', 'cekot@smkn11kotabekasi.actudent.com', '$2y$10$Gx4MOrOMnQUf5vUm3SjhXe8RDILcDHjctiEZ6zZxUb6y9GqCPjsZK', 0, 1, 'offline', '2020-02-10 08:19:31', '2022-11-28 15:51:57'),
	(38, 'dgjhrsjthj', 'ihi@smkn11kotabekasi.actudent.com', '$2y$10$xSKCnhM0Puv6Ws4.9/lQxuykJf0NLUCRosZHnSNzDBB4ihZ5mvsMa', 0, 1, 'offline', '2020-02-10 08:20:15', '2022-11-29 02:31:24'),
	(39, 'Mugiono Apriyani', 'mugiono.apriyani@smkn11kotabekasi.actudent.com', '$2y$10$FSiwxDs87YTx2k44TpACr.DVlvtjQyyAgNApefDpWuer4CC5Dz0Hu', 0, 1, 'offline', '2020-02-10 08:31:25', '2022-11-29 02:32:12'),
	(40, 'Linda Sukmawati', 'linda.sukma@smkn11kotabekasi.actudent.com', '$2y$10$RzAC35rNJShVZjB8EYZYoe9UVwu/oGOgZF4XaSu1XgynBlOhpGiZW', 0, 1, 'offline', '2020-02-20 04:25:09', '2020-06-17 07:20:50'),
	(41, 'Berry Sihalahua', 'berry.sihala@smkn11kotabekasi.actudent.com', '$2y$10$3p8fGp7UrvUBQgb8eIN9E.rb9DuS0Rco2AFzRdyc1acXFS/b9LRq.', 0, 1, 'offline', '2020-03-10 07:32:22', '2022-11-29 02:31:04'),
	(42, 'Abdul Jabbar', 'abduljabbar@smkn11kotabekasi.actudent.com', '$2y$10$GxMQ9W8Oh/urNJteKMQB8uA/lpoSAouTZE4p7xF/F4BFej7BWytl2', 0, 1, 'offline', '2020-03-10 07:34:54', '2022-11-28 08:50:23'),
	(43, 'Riko Tantorini', 'rikotanto@smkn11kotabekasi.actudent.com', '$2y$10$MQ8K72/H/xm0l1LCHDXYRuQerQYknJMynU6Dr37Pkl/IuywjVyktS', 0, 1, 'offline', '2020-03-11 13:09:01', '2022-11-29 02:32:25'),
	(44, 'Rian Mangkulangit', 'rianmangkulangit@smkn11kotabekasi.actudent.com', '$2y$10$KfyKWSudFaaSQVxByz3jzubP0VQC54lu/njLp3ezC/DXg9oqbUYhG', 0, 1, 'offline', '2020-03-13 00:11:26', '2022-11-29 02:32:23'),
	(45, 'Reinhard Oktora', 'reinhard.oktora@smkn11kotabekasi.actudent.com', '$2y$10$Vvnfh0n5jC29K2U3k90h0unCWwc7Sm8jIxo1NKycYe016EctK3cSe', 0, 1, 'offline', '2020-03-13 00:12:31', '2022-11-29 02:32:20'),
	(46, 'Baharudin Saifulloh', 'baharsaiful@smkn11kotabekasi.actudent.com', '$2y$10$fmGet4t.IjLkL3.8KgJvpuaMPfwqFKGE.ZEw6A2XCnX2gaN3aqgMi', 0, 1, 'offline', '2020-04-03 13:06:55', '2020-06-17 07:20:50'),
	(47, 'Indah Dwi Hartati', 'indahhartati@smkn11kotabekasi.actudent.com', '$2y$10$KKPF1a.COnWa4.6HLI4GWutggcWTNFImmFX.ufjXv3UWtnCKl.GHS', 0, 1, 'offline', '2020-04-06 01:39:35', '2022-11-29 02:32:01'),
	(48, 'Lintang Sudarmanto', 'lintangsudarmanto@smkn11kotabekasi.actudent.com', '$2y$10$K7LrXPpLuRs/a8cJjr0muOAz4fht.aeuvJspz2g1v9gCVIsAsq11u', 0, 1, 'offline', '2020-04-06 01:40:30', '2022-11-29 02:32:08'),
	(49, 'Abdal Salem', 'abdalsalem@smkn11kotabekasi.actudent.com', '$2y$10$ZdISGSPBBg7k2LjZnLFsJOjhrYiQvM3QdWftzQNj/h.HyALFrJHD.', 2, 0, 'offline', '2020-04-06 01:43:50', '2022-11-29 06:09:12'),
	(50, 'Edwin Susanto', 'edwin.susanto@smkn11kotabekasi.actudent.com', '$2y$10$U7FyAdvPZnarAk0molJo2uAZmIlv63vzjdrbZy9Skv8se.bAOfQ2e', 0, 1, 'offline', '2020-04-17 10:12:26', '2022-11-29 02:31:27'),
	(51, 'Indri Sintiasari', 'indrisintia@smkn999kotabekasi.actudent.com', '$2y$10$rAUBYcBeGxkhSW2D3lfF.OiNQv2fUbd.tSCygzAYmaFb4albHylAi', 3, 0, 'offline', '2020-07-09 05:36:01', '2020-07-09 05:36:01'),
	(52, 'Kartono', 'kartono99@smkn999kotabekasi.actudent.com', '$2y$10$xJ7jc.uJFjrkBagIWzhE5OeUsH5ScATBmt.r5JQ6E9rb4lu5qjHae', 3, 0, 'offline', '2020-07-09 05:37:39', '2020-07-09 05:37:39'),
	(53, 'Muhammad Rizal', 'mrizal@localhost', '$2y$10$VV1nFPRnYpvAUkgvI9PcGOj/aGvqcxAFyyX3UvdVCoJC4lotKnoDW', 2, 0, 'online', '2020-07-10 05:47:57', '2022-05-24 16:02:27'),
	(54, 'Administrator', 'admin@demo.actudent.com', '$2y$10$gKk1sx1Jx/cXx2L8BolU4emqDn2Kg/zSr9hqOb7Syo5NpisY.QnwC', 1, 0, 'online', '2021-02-03 02:45:55', '2021-03-15 06:40:13'),
	(55, 'Abdul Majid', 'abdulmajid97@demo.actudent.com', '$2y$10$HzH7jhmpnhT4/GFjT76ZieUO2VF3joByaXh1bdUMIR04it2wDgaPe', 3, 0, 'offline', '2021-05-17 04:29:42', '2021-05-17 04:29:42'),
	(56, 'jsndfjsn', 'kjnjfnfj@demo.actudent.com', '$2y$10$I1YR8I.lA1DqE33igLMKZOOmRaETKcvNE9MWVSupo9n2Js4aKX0OG', 3, 1, 'offline', '2021-05-17 08:06:27', '2023-04-20 03:11:43'),
	(57, 'Ibnu Kamil', 'ibnukamil87@demo.actudent.com', '$2y$10$ZWMk7ceGzAWmmSvP6usSjuUOpqdrHSZEhV0s.xHryn25ZWmXV1/p6', 3, 0, 'offline', '2021-05-17 08:28:06', '2021-05-17 08:28:06'),
	(58, 'Ahmad Hasan ', 'rinapuspita@demo.actudent.com', '$2y$10$M7nn0bSfzdNeWGX8CQU7HOaBCej3f8TZbqg80P1PzqAe/AVP0x2dq', 3, 0, 'offline', '2021-05-17 08:30:35', '2021-05-17 08:30:35'),
	(59, 'Ahmad Fajrul', 'rinarosinta@demo.actudent.com', '$2y$10$rlLUPusxbvy2apBACoZESeopwNw4VAPSJ4SUk78mUOs.r2Up2h5i6', 3, 0, 'offline', '2021-05-17 08:31:31', '2021-05-17 08:31:31'),
	(60, 'Rima Nurmala', 'rimanurmala@demo.actudent.com', '$2y$10$wVX5tG1g.54Az.Crlhafpe.WGqn8LriawV8ZuAmMEJ77H4vCWsKQa', 3, 1, 'offline', '2021-05-17 10:28:06', '2023-04-20 03:24:13'),
	(61, 'Adi Sumarno', 'adi_sumarno@demo.actudent.com', '$2y$10$VLnn68bLggBLVPnZN0T69O/iHH0Tj6NuMA9L80MyFiH8jhmLaTt3y', 3, 0, 'offline', '2021-05-17 10:44:07', '2021-05-17 10:44:07'),
	(62, 'Hamdan Syakirin', 'hamdans@demo.actudent.com', '$2y$10$hn1XSqIpxicTxlOznrNIv.UQ9ODXxwh09otNbLZKGBPM/l/rGILF2', 3, 0, 'offline', '2021-05-17 10:48:17', '2021-05-17 10:48:17'),
	(63, 'Hamdan Naimin', 'hamdanna@demo.actudent.com', '$2y$10$dweEpb382S4Y6V.uVi5XYOcvEUYDnlpheqPpNmcU1DTWgmwD6FF9m', 3, 0, 'offline', '2021-05-17 10:57:22', '2021-05-17 10:57:22'),
	(64, 'Syarif Romadhon', 'syarif_r192@demo.actudent.com', '$2y$10$8kS86VVcEX8dp9qYJolqNuO18GWOD7dFsgLoVHYqAe4L2A99//Zmu', 3, 0, 'offline', '2021-05-17 12:56:31', '2021-05-17 12:56:31'),
	(65, 'Izzatul Islam', 'izzatul_islam@demo.actudent.com', '$2y$10$OXaD.DmIdONG/9LvqCaaP.yHDvZbSuHF6I7zMLcDJPyhMBP9O5biO', 3, 0, 'offline', '2021-05-17 13:04:32', '2021-05-17 13:04:32'),
	(66, 'Abdul Fattah', 'abdulfattah@demo.actudent.com', '$2y$10$a8UdokSBwOoIGUdrkTHhkODvY9p3Qw208zyDE3fcW1Tue/6uFH.5q', 3, 0, 'offline', '2021-05-17 13:05:20', '2021-05-17 13:05:20'),
	(67, 'Himdin', 'himdin982@demo.actudent.com', '$2y$10$dCgnt6HfDhFtB.xor0sBqOfPPjlk7C/JArrPyAIeqI5.S/aETK0Ly', 3, 0, 'offline', '2021-05-17 13:09:31', '2021-05-17 13:09:31'),
	(68, 'Huntu', 'huntu92@demo.actudent.com', '$2y$10$9ldHEXaRC.nBLCaeUnUF0.eNDSrLfBtpicebe2sPQly/.Wc0YxFi.', 3, 0, 'offline', '2021-05-18 05:25:52', '2021-05-18 05:25:52'),
	(69, 'Ryan Dahl', 'ryandahl@demo.actudent.com', '$2y$10$86LpWxDE.13BHsHydQWniObNQvt0U5qdUMYkbfS.HHJogw5rXMyX2', 2, 0, 'offline', '2022-06-16 05:44:57', '2022-06-16 05:44:57'),
	(70, 'Ryan Dahl', 'ryan dahl@demo.actudent.com', '$2y$10$XFLlm6ifXRPXXhNQoTkCz.7q04tVPbuoQxu8yo6QCBUB47sbu4vK6', 2, 1, 'offline', '2022-06-16 05:46:16', '2022-06-16 05:46:32'),
	(71, 'Linus Torvalds', 'linustor@demo.actudent.com', '$2y$10$yoeC7KCelDFvW21iDhRfx.LV.13CgKHa.r1PflDWUhvAZVJI51BeO', 2, 0, 'offline', '2022-06-16 05:47:26', '2022-06-16 05:47:26'),
	(72, 'Abraham Lincoln', 'abrahamlincoln@demo.actudent.com', '$2y$10$h.n7/I3GvVAUV83RItJBt.86eEOKYaZy.qcoH4i0lPWbyPikZ1Jum', 2, 0, 'offline', '2022-06-16 05:49:51', '2022-06-16 05:49:51'),
	(73, 'Ebino Gaban', 'ebinogaban@demo.actudent.com', '$2y$10$bvnJN7jUW.S8se6zoatadOcwfF85hTs9T184s0sv3VJVfYGW2Stme', 2, 0, 'offline', '2022-06-16 05:52:02', '2022-06-16 05:52:02'),
	(74, 'Faruq As-Sahab', 'faruqsahab@demo.actudent.com', '$2y$10$4jcbZ9fBJC4E7fm13dhAzONvs2tgpiZw7tDHyzdCju5W5yCM0UzXy', 3, 0, 'offline', '2022-06-16 06:01:58', '2022-06-16 06:01:58'),
	(75, 'Andi Irawan', 'andiirawan@demo.actudent.com', '$2y$10$9cXn7JnvPywziAqbw7QD7.4GzBOEkqoAvXCzhFr5TyFk4AEiMah5S', 3, 0, 'online', '2022-06-26 17:20:43', '2022-06-26 17:23:41'),
	(76, 'Abaababa', 'ababaafy@demo.actudent.com', '$2y$10$tL2O9aGtzEnsw1OjZI/GhuBqcKN3Ui6L0xaOUVo01kb7rrzMmIJNe', 2, 1, 'offline', '2022-06-26 17:23:07', '2022-06-26 17:23:20'),
	(77, 'Zidan Abdiyan', 'zidanabdiyan@demo.actudent.com', '$2y$10$Cp0lvQb3XdtQJ77pAId9eO8BdS7SzyN7WXRRP0.WqK8UTsX8Bs5hS', 3, 1, 'offline', '2022-06-30 04:36:45', '2023-04-20 03:13:01'),
	(78, 'Indra Setiawan', 'NULL', '$2y$10$dOXyBumqbaLY6S7bYvymvenBc9H8EncwI.iPbn67Zzf79UBXr3Qvm', 2, 0, 'online', '2022-09-06 04:56:55', '2022-09-06 07:50:29'),
	(79, 'Ibrahim Al-Awwad Al-Baihaki', 'ibrahimawwad@gmail.com', '$2y$10$M4TvTjii7L3ZzRyVjc/OmOd8JT0bjs3inBTPM/7stJfIKv2rC1CVO', 0, 0, 'offline', '2022-09-09 08:03:08', '2022-11-28 15:29:47'),
	(80, 'Reyhan Pratama ', 'reyhanpratama@gmail.com', '$2y$10$AWyLRrv6yBwXuqhnfPqKzeqqYrZRc66UsaF6SGTjkd2iaBeAIW8qC', 0, 0, 'offline', '2022-11-28 15:00:42', '2022-11-28 15:22:51'),
	(81, 'Muhammad Ibrahim', 'mibrahim@demo.actudent.com', '$2y$10$UwObcZIBYdR7N9vu2.egqO2A.coDJUfYSwFFPQdvtVJt/TjZVCa5C', 3, 1, 'offline', '2023-04-15 04:03:19', '2023-04-15 04:05:26'),
	(82, 'Dorawati Candra', 'indralesmana222@gmail.com', '$2y$10$pbDUYzqE6ZdOH.9Wj9ILf.Fn89ts87kQpcgnYjCd6OWN.JyDOcfN2', 0, 1, 'offline', '2023-04-17 06:58:19', '2023-04-17 06:58:56'),
	(83, 'Sahrul Aminin', 'sahrulaminin90@demo.actudent.com', '$2y$10$BqsTuKboZZJ9as5JumU5x.cyNqffj8qiAJhcW8HOFEp/nPeEXLeK.', 3, 1, 'offline', '2023-06-27 02:44:26', '2023-06-27 02:44:38'),
	(84, 'Adrian Simatupang', 'adriansimatupan8839@demo.actudent.com', '$2y$10$oFeNnU2i7TwApkr8jciA6eRicTpkIqkNmagGuJaWefScMODW2QrPe', 3, 1, 'offline', '2023-06-27 03:27:39', '2023-06-27 03:27:56');

-- Dumping structure for table db_actudent_sync.tb_user_devices
CREATE TABLE IF NOT EXISTS `tb_user_devices` (
  `device_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `device_type` varchar(100) DEFAULT NULL,
  `device_version` varchar(100) DEFAULT NULL,
  `fcm_registration_id` varchar(500) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`device_id`),
  KEY `user_device` (`user_id`),
  CONSTRAINT `user_device` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table db_actudent_sync.tb_user_devices: ~3 rows (approximately)
DELETE FROM `tb_user_devices`;
INSERT INTO `tb_user_devices` (`device_id`, `user_id`, `device_type`, `device_version`, `fcm_registration_id`, `status`, `created`, `modified`) VALUES
	(1, 30, 'ANDROID', '24', 'ePCVe_8USAeZ3yUNvdp1RK:APA91bHRFNlwF1BfnC2Z0o4LFLzdYTEWEZ-oj332vbPWdEzaIbaZnId-bw-R7YQeok5aBl8oETGdrohxGZUPwk8V6PTm5vmhJGuhCZgSE8mtHpxvNygnex72_7jt3gTllZkaaaIWfNFG', 1, '2020-06-30 08:59:03', '2020-11-13 05:59:06'),
	(2, 13, 'ANDROID', '22', 'c-YZKEFAQiyOw6clw_Te5V:APA91bHTXYu1VowS715yDVaP1X5tW1wJAQjrJIFdPEfKYGN0Cyw3WmWPaEIteTpCNV81ZNnO7tEy1mUFZSCk1WxPn-dLbdLVYQwfqm0yz8V3B7zN5-lYdKI-Q4icJWgr_idEnQjaVkdJ', 0, '2020-06-30 10:12:35', '2020-07-11 01:57:19'),
	(3, 53, 'ANDROID', '29', 'fcDzlt1TSZKGmb6WJPHmVf:APA91bHfyz4df_gdrbdsttsqbVYJwJrJnNEbfm0P2_zPxk7zQ0U0xo8y0D4Eds3vExnYc9M-RxOBNPmCr9UrtAht_X-lK6A79bYifto46E_dnUSd9wY489Ms7c9qkUMZz8y39UGt9QiT', 1, '2020-07-10 06:27:35', '2020-12-16 11:04:41');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
