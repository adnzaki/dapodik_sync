<?php
$nama = "Syifa'udin M.";
$remove = ['.', "'", 'x'];
$replace = ['', '', 'y'];
$clean = str_replace($remove, $replace, $nama);

echo $clean;

